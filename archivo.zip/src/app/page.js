"use client";

import Inicio from "@/app/screens/home/page";

export default function page() {
  return (
    <>
      <Inicio />
    </>
  );
}
